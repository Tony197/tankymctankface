﻿using UnityEngine;
using System.Collections;

public class Turns : MonoBehaviour {

    private bool usmove = false;
    private bool usattack = false;

    private bool germanymove = false;
    private bool germanyattack = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(Input.GetButtonDown("Fire1") && !usmove && !usattack && !germanymove && !germanyattack)
        {
            usmove = true;
        }

        if(Input.GetButtonDown("Fire2") && !usmove && !usattack && !germanymove && !germanyattack)
        {
            germanymove = true;
        }

        if(usmove)
        {
            if (Input.GetButtonDown("Fire1") && !usattack && !germanymove && !germanyattack)
            {
                usmove = false;
                usattack = true;

                Debug.Log("U.S Move");
            }
        }

        if(usattack)
        {
            if (Input.GetButtonDown("Fire1") && !usmove && !germanymove && !germanyattack)
            {
                usattack = false;
                germanymove = true;

                Debug.Log("U.S Attack");
            }
        }

        if(germanymove)
        {
            if (Input.GetButtonDown("Fire1") && !usmove && !usattack && !germanyattack)
            {
                germanymove = false;
                germanyattack = true;

                Debug.Log("Germany Move");
            }
        }

        if(germanyattack)
        {
            if (Input.GetButtonDown("Fire1") && !usmove && !usattack && !germanymove)
            {
                germanyattack = false;
                usmove = true;

                Debug.Log("Germany Attack");
            }
        }
	}
}
