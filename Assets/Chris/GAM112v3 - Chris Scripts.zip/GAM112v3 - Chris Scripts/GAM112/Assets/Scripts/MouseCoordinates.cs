﻿using UnityEngine;
using System.Collections;

public class MouseCoordinates : MonoBehaviour
{
    private bool UseWorldCoordinates = false;
    // Update is called once per frame
    void update()
    {
        // toggle the bool value of UseWorldCoordinates
        if (Input.GetButtonUp("Fire1"))
        {
            UseWorldCoordinates = !UseWorldCoordinates;
        }

        if (UseWorldCoordinates)
        {
            Debug.Log(GetComponent<Camera>().ScreenPointToRay(Input.mousePosition));
        }
        else
        {
            Debug.Log(Input.mousePosition);
        }
    }
}
