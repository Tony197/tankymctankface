﻿//using UnityEngine;
//using System.Collections;
//using UnityEngine.UI;

//public class LerpMover : MonoBehaviour {

//	public Transform target;

//	// Use this for initialization
//	void Start () 
//	{
//		transform.position = Vector3.Lerp (transform, ImagePosition, target.position, 0.1f * Time.deltaTime);
//	}
//}