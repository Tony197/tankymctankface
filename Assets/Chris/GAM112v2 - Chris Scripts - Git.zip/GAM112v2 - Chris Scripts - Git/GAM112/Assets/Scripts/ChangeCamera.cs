﻿using UnityEngine;
using System.Collections;

public class ChangeCamera : MonoBehaviour 
{
	private Camera MainCamera;

	private bool TopDownOn = false;

	// Use this for initialization
	void Start () 
	{
		MainCamera = GameObject.Find ("Main Camera").GetComponent<Camera> ();
	}

	public void OnMouseDown ()
	{
		TopDownOn = !TopDownOn;

		if (TopDownOn) 
		{
			// set position
			MainCamera.transform.position = new Vector3 (0, 10, 0);
			Debug.Log ("UP");
		}
		else
		{
			// set position
			MainCamera.transform.position = new Vector3 (0, 1, -10);
			Debug.Log("DOWN");
		}

		// set rotation
		MainCamera.transform.LookAt(Vector3.zero);
	}
}
